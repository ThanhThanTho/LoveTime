package com.vn.thanhnx.countingtimetogether;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private ImageView firstPic;

    private ImageView secondPic;

    private TextView textViewCounting;

    private void bindingView(){
        firstPic = findViewById(R.id.imageView);
        secondPic = findViewById(R.id.imageView2);
        textViewCounting = findViewById(R.id.textView);
    }

    private void bindingAction(){
        firstPic.setOnClickListener(this::firstPicClick);
        secondPic.setOnClickListener(this::secondPicClick);
    }

    private void secondPicClick(View view) {
    }

    private void firstPicClick(View view) {
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        bindingView();
        bindingAction();
    }
}